﻿namespace Solid_Master.ChainOfResponsibility.After
{
    class Document
    {
        public string Name { get; set; }
        public int WordCount { get; set; }
    }
}
