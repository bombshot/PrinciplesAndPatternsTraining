﻿namespace Solid_Master.ChainOfResponsibility.Before
{
    class Document
    {
        public string Name { get; set; }
        public int WordCount { get; set; }
    }
}
